

<script src="<?php echo e(asset('template/js/jquery.min.js')); ?>"></script>       
<script src="<?php echo e(asset('template/js/jquery-3.3.1.slim.min.js')); ?>"></script>

<script src="<?php echo e(asset('template/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/js/bootstrap.min.js')); ?>"></script>



</body>
</html>

<?php /**PATH C:\xampp\htdocs\oes\resources\views/pages/footer.blade.php ENDPATH**/ ?>