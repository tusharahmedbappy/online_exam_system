<?php $__env->startSection('exam_content'); ?>
    <div class="container">
        <div class="card card-body">
            <div class="questioinSection">
                <form action="<?php echo e(url('/next/question')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php $__currentLoopData = $question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quesData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class=" bg-default">
                            <h2 class="text-light text-center">Question <?php echo e($quesData->ques_no); ?> of <?php echo e($quesData->count()); ?> </h2>

                        </div>
                        <h2 class="pl-3">Ques <?php echo e($quesData->ques_no); ?>:- <?php echo e($quesData->question); ?>

                            <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger">Please Select an Answer</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <hr>
                        </h2>

                        <input type="hidden" name="question_id" value="<?php echo e($quesData->ques_no); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="">
                        <?php $__currentLoopData = $answer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ansData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <ul class="form-check">
                            <li>
                                <input type="radio" value="<?php echo e($ansData->id); ?>" name="question" id="checkbox1">
                                <label class="">
                                    <?php echo e($ansData->ans); ?>

                                </label>
                            </li>
                        </ul>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <button class="btn btn-default px-5">Next Question</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.exam_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\oes\resources\views/pages/exam_plate.blade.php ENDPATH**/ ?>