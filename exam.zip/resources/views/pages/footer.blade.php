

<script src="{{asset('template/js/jquery.min.js')}}"></script>       
<script src="{{asset('template/js/jquery-3.3.1.slim.min.js')}}"></script>

<script src="{{asset('template/js/popper.min.js')}}"></script>
<script src="{{asset('template/js/bootstrap.min.js')}}"></script>



</body>
</html>

