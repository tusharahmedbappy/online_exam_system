@extends('Admin_panel.dashboard')
@section('dashboard_content')
    <div class="container">
        <div class="card card-body mt-5">
                <div class="col-md-10 m-auto">
                        <h1 class="text-center text-warning ">ADMIN PANEL <hr></h1>
                        <h2 class="text-center mt-5">Welcome Administrator to admin panel</h2>
                    </div>
        </div>
    </div>
@endsection