<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{asset('template/css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('template/css/font-awesome.min.css')}}">
    <link rel="stylesheet" href="{{asset('template/js/plugins/@fortawesome/fontawesome-free/css/all.min.css')}}">
    <link rel="stylesheet" href="{{asset('template/js/plugins/nucleo/css/nucleo.css')}}">
    <link rel="stylesheet" href="{{asset('template/css/line-awesome.min.css')}}">
    <link rel="stylesheet" href="{{asset('template/css/style.css')}}">
    {{--    dashboard css--}}
    <link rel="stylesheet" href="{{asset('template/dashboard/css/argon-dashboard.css')}}">
    
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>

    <title>Online | Exam | system</title>

</head>
<body>

