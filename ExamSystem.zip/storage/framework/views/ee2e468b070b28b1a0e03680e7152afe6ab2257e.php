<?php echo $__env->make('pages.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="mainBody">
    <div class="container">
        <div class="col-md-10 col-lg-10 col-sm-10 padding-5 m-auto">
            <div class="contentBody">
                <?php echo $__env->yieldContent('content'); ?>
                <!-- <div class="my-3">
                    <a href="<?php echo e(url('/register')); ?>" class="btn btn-danger">Register</a>
                    <a href="<?php echo e(url('/login')); ?>" class="btn btn-danger">Login</a>
                </div> -->
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('pages.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\oes\resources\views/index.blade.php ENDPATH**/ ?>