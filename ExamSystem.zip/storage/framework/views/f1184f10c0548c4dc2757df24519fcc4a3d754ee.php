<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="col-md-7 pt-3 m-auto">
        <div class="formHeader">
            <h3 class="text-center">User Register</h3>
            <div class="text-center">
                <div class="btn-wrapper text-center">
                    <a href="#" class="btn  btn-icon">
                        <span class="btn-inner--icon">
                            <img src="<?php echo e(asset('template/img/icons/common/github.svg')); ?>">
                        </span>
                        <span class="btn-inner--text">Github</span>
                    </a>
                    <a href="#" class="btn  btn-icon">
                        <span class="btn-inner--icon">
                            <img src="<?php echo e(asset('template/img/icons/common/google.svg')); ?>">
                        </span>
                        <span class="btn-inner--text">Google</span>
                    </a>
                </div>
            </div>
            <hr>
        </div>
        <form action="<?php echo e(url('/register/submit')); ?>" method="post">
            <?php echo csrf_field(); ?>
                <div class="form-group mb-3">
                        <div class="input-group input-group-alternative">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fa fa-user"></i>
                                </span>
                            </div>
                            <input type="text" name="name" class="form-control" placeholder="Name" >
                        </div>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <strong class="text-danger"><?php echo e($message); ?></strong>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
            <div class="form-group mb-3">
                <div class="input-group input-group-alternative">
                    <div class="input-group-prepend">
                        <span class="input-group-text">
                            <i class="ni ni-email-83"></i>
                        </span>
                    </div>
                    <input type="email" name="email" class="form-control" placeholder="Email" >
                </div>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <div class="input-group input-group-alternative">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                    </div>
                    <input type="password" name="password" class="form-control" placeholder="Password" >
                </div>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <?php if(session('already_used')): ?>
                <strong class="text-danger"> <?php echo e(session('already_used')); ?></strong>

            <?php endif; ?>
            <div class="custom-control custom-control-alternative custom-checkbox">
                <input class="custom-control-input" id=" customCheckLogin" type="checkbox">
                <label class="custom-control-label" for=" customCheckLogin">
                    <span class="text-muted">Remember me</span>
                </label>
            </div>
            <div class="text-center">
                <button type="submit" class="btn btn-default px-5">Sign up</button>
            </div>
            <div class="loginBtn">
                <a href="<?php echo e(url('/')); ?>" class="btn">Have an account_!
                </a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\oes\resources\views/auth/register.blade.php ENDPATH**/ ?>