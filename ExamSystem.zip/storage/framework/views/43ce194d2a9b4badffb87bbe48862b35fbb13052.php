<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="col-md-6 pt-5 m-auto">
        <div class="formHeader">
            <h2 class="text-center">Admin Log In </h2>
            <hr>
        </div>
    <form action="<?php echo e(url('/login')); ?>" method="POST">
        <?php echo csrf_field(); ?>
            <div class="form-group my-3">
                <div class="input-group input-group-alternative">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="ni ni-email-83"></i></span>
                    </div>
                    <input class="form-control" name="email" placeholder="Email" type="email">
                </div>
            </div>
            <div class="form-group">
                <div class="input-group input-group-alternative">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                    </div>
                    <input class="form-control" name="password" placeholder="Password" type="password">
                </div>
            </div>
            <div class="custom-control custom-control-alternative custom-checkbox">
                <input class="custom-control-input" id=" customCheckLogin" type="checkbox">
                <label class="custom-control-label" for=" customCheckLogin">
                    <span class="text-muted">Remember me</span>

                </label>

            </div>
            <div class="text-center">
                <button type="submit" class="btn btn-default px-5 mt-4">Sign in</button>
            </div>
            <div class="registerBtn">
                    <a href="<?php echo e(url('/register')); ?>" class="btn">Create an account_! 
                    </a>
            </div>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\oes\resources\views/admin_panel/admin_panel_login.blade.php ENDPATH**/ ?>