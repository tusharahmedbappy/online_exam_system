<?php $__env->startSection('exam_content'); ?>
    <div class="col-md-6 m-auto">
        <h1 class="text-center text-warning">Test your knowledge! <hr></h1>
        <div class="mb-4">
                <span>This is multiple choice quiz to test your knowledge</span>
                <strong>Number of questions : 10</strong><br>
                <strong>Question type :</strong><span>Multiple choice</span><br>
        </div>
        <a href="<?php echo e(url('/questions',1)); ?>" class="btn btn-warning px-5">Start test</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.exam_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\oes\resources\views/pages/exam_info.blade.php ENDPATH**/ ?>